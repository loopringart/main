<?php
if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

/**
 * Load the same plugin compat class.
 */
require_once 'wp-smushit.php';
